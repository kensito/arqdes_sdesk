package exercicio6_1;

public class MensagemTerca implements MensagemDoDia {

	@Override
	public void imprime() {
		System.out.println("Ter�a tem bife a rol�");
	}

}
