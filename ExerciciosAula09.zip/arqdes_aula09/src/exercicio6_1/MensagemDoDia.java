package exercicio6_1;

public interface MensagemDoDia {
	void imprime();
}
