package exercicio6_1;

public class MensagemSegunda implements MensagemDoDia {

	@Override
	public void imprime() {
		System.out.println("Hoje � segunda, Dia de Virada Paulista");
	}

}
