package exercicio6_1;

public class MensagemSexta implements MensagemDoDia {

	@Override
	public void imprime() {
		System.out.println("Fizz assado!!!");
	}

}
