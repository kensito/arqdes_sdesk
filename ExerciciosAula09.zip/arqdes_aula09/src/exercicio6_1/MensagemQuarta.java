package exercicio6_1;

public class MensagemQuarta implements MensagemDoDia {

	@Override
	public void imprime() {
		System.out.println("Quarta tem fejuca");
	}

}
