package exercicio6_1;

public class MensagemSabado implements MensagemDoDia {

	@Override
	public void imprime() {
		System.out.println("Sobra de Quarta!!!!!!!");
	}

}
