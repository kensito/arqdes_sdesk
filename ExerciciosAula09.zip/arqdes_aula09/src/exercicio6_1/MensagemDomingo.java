package exercicio6_1;

public class MensagemDomingo implements MensagemDoDia {

	@Override
	public void imprime() {
		System.out.println("Abre a geladeira pega a catuaba");
	}

}
