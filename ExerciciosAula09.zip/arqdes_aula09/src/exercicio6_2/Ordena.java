package exercicio6_2;

public interface Ordena {
	int[] ordem(int[] v);
}
