package Exercicio1_1;

public interface AbstractEscritorFactory {

	Escritor getEscritorInstance(int escritorType);
}
